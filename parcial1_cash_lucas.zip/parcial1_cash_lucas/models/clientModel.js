const mongoose = require('mongoose');

const Schema = mongoose.Schema; 

const clienteSchema = new Schema ({
    nombre: {
        type: String,
        required: true
    },
    correo: {
        type: String,
        required: true
    },
    direccion: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
})

const Cliente = mongoose.model( 'Cliente', clienteSchema );

module.exports = Cliente;