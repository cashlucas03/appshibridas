const mongoose = require('mongoose');

const Schema = mongoose.Schema; 

const pedidoSchema  = new Schema ({
    cliente: { 
        type: Schema.Types.ObjectId, 
        ref: 'Cliente',
        required: true
    },
    productos: [
        { 
            type: Schema.Types.ObjectId, 
            ref: 'Producto',
            required: true 
        }
    ],
    fecha: {
        type: Date,
        default: Date.now
    },
    total: {
        type: Number, 
        required: true
    }
})

const Pedido  = mongoose.model( 'Pedido', pedidoSchema  );

module.exports = Pedido;