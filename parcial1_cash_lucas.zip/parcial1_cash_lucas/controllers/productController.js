const Producto = require('../models/productModel');

const productoController = {
  listarProductos: async (req, res) => {
    try {
      const productos = await Producto.find();
      res.json(productos);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener los productos' });
    }
  },

  obtenerProductoPorId: async (req, res) => {
    const { id } = req.params;
    try {
      const producto = await Producto.findById(id);
      if (!producto) {
        return res.status(404).json({ error: 'Producto no encontrado' });
      }
      res.json(producto);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener el producto' });
    }
  },

  crearProducto: async (req, res) => {
    const { nombre, descripcion, precio, categoria } = req.body;
    try {
      const nuevoProducto = new Producto({ nombre, descripcion, precio, categoria });
      const productoGuardado = await nuevoProducto.save();
      res.status(201).json({
        msg: 'Producto Creado',
        data: productoGuardado
    })
    } catch (error) {
      res.status(500).json({ error: 'Error al crear el producto' });
    }
  },

  actualizarProducto: async (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion, precio, categoria } = req.body;
    try {
      const producto = await Producto.findByIdAndUpdate(id, { nombre, descripcion, precio, categoria }, { new: true });
      if (!producto) {
        return res.status(404).json({ error: 'Producto no encontrado' });
      }
      res.json(producto);
    } catch (error) {
      res.status(500).json({ error: 'Error al actualizar el producto' });
    }
  },

  eliminarProducto: async (req, res) => {
    const { id } = req.params;
    try {
      const producto = await Producto.findByIdAndRemove(id);
      if (!producto) {
        return res.status(404).json({ error: 'Producto no encontrado' });
      }
      res.json({ message: 'Producto eliminado correctamente' });
    } catch (error) {
      res.status(500).json({ error: 'Error al eliminar el producto' });
    }
  },
};

module.exports = productoController;
