const Pedido = require('../models/orderModel');
const Producto = require('../models/productModel');

const orderController = {
  listarPedidos: async (req, res) => {
    try {
      const pedidos = await Pedido.find();
      res.json(pedidos);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener los pedidos' });
    }
  },

  obtenerPedidoPorId: async (req, res) => {
    const { id } = req.params;
    try {
      const pedido = await Pedido.findById(id);
      if (!pedido) {
        return res.status(404).json({ error: 'Pedido no encontrado' });
      }
      res.json(pedido);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener el pedido' });
    }
  },

  crearPedido: async (req, res) => {
    const { cliente, productos, fecha } = req.body;

    try {
     
      const total = await calcularTotal(productos);

      const nuevoPedido = new Pedido({ cliente, productos, fecha, total });
      const pedidoGuardado = await nuevoPedido.save();
      res.status(201).json({
        msg: 'Pedido almacenado',
        data: pedidoGuardado
    })
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Error al crear el pedido' });
    }
  },

  actualizarPedido: async (req, res) => {
    const { id } = req.params;
    const { cliente, productos, fecha, total } = req.body;
    try {
      const pedido = await Pedido.findByIdAndUpdate(id, { cliente, productos, fecha, total }, { new: true });
      if (!pedido) {
        return res.status(404).json({ error: 'Pedido no encontrado' });
      }
      res.json(pedido);
    } catch (error) {
      res.status(500).json({ error: 'Error al actualizar el pedido' });
    }
  },

  eliminarPedido: async (req, res) => {
    const { id } = req.params;
    try {
      const pedido = await Pedido.findByIdAndRemove(id);
      if (!pedido) {
        return res.status(404).json({ error: 'Pedido no encontrado' });
      }
      res.json({ message: 'Pedido eliminado correctamente' });
    } catch (error) {
      res.status(500).json({ error: 'Error al eliminar el pedido' });
    }
  },
};

async function calcularTotal(productos) {
  let total = 0;
  for (const productoId of productos) {
    const producto = await Producto.findById(productoId);
    if (producto) {
      total += producto.precio;
    }
  }
  return total;
}


module.exports = orderController;
