const express = require("express");
const fs = require("fs").promises;

const router = express();
const pathJSON = "./data/alumnos.json";

router.get("/", async (req, res) => {
  try {
    const data = JSON.parse(await fs.readFile(pathJSON, "utf-8"));
    let html = `<ul>`;

    data.forEach((alumno) => {
      html += `<li> ${alumno.nombre} ${alumno.apellido} <a href="alumnos/${alumno.legajo}"> detalle </a> </li>`;
    });
    html += `</ul>`;

    console.log(data);

    res.send(`<h1>Listado de alumnos</h1>` + html);
  } catch (error) {
    res.json({
      msg: "Error en el Servidor ",
    });
  }
});

router.get("/:legajo", async (req, res) => {
  const { legajo } = req.params;
  let alumnoDetalle = {};
  const data = JSON.parse(await fs.readFile(pathJSON, "utf-8"));

  data.forEach((alumno) => {
    if (alumno.legajo == legajo) {
      alumnoDetalle = alumno;
    }
  });

  if (alumnoDetalle) {
    res.status(200).json(alumnoDetalle);
  } else {
    res.status(404).json({
      msg: "Alumno no encotrado",
    });
  }
});

router.post("/", async (req, res) => {
  const nuevoAlumno = req.body;
  try {
    const data = await fs.readFile(pathJSON, "utf-8");
    const alumnos = JSON.parse(data);
    alumnos.push(nuevoAlumno);
    await fs.writeFile("./data/alumnos.json", JSON.stringify(alumnos, null, 2));
    res.json(nuevoAlumno);
  } catch (err) {
    res.status(500).json({ msg: "No se pudo agregar el alumno" });
  }
});

router.put("/:legajo", async (req, res) => {
  const legajo = Number(req.params.legajo);
  const nuevosDatos = req.body;
  try {
    const data = await fs.readFile("./data/alumnos.json", "utf-8");
    const alumnos = JSON.parse(data);
    const index = alumnos.findIndex((a) => a.legajo === legajo);
    if (index !== -1) {
      alumnos[index] = { ...alumnos[index], ...nuevosDatos };
      await fs.writeFile(
        "./data/alumnos.json",
        JSON.stringify(alumnos, null, 2)
      );
      res.json(alumnos[index]);
    } else {
      res.status(404).json({ msg: "Alumno no encontrado" });
    }
  } catch (err) {
    res.status(500).json({ msg: "No se pudo modificar el alumno" });
  }
});

router.delete("/:legajo", async (req, res) => {
  const legajo = Number(req.params.legajo);
  try {
    const data = await fs.readFile("./data/alumnos.json", "utf-8");
    let alumnos = JSON.parse(data);
    const index = alumnos.findIndex((a) => a.legajo === legajo);
    if (index !== -1) {
      alumnos = alumnos.filter((a) => a.legajo !== legajo);
      await fs.writeFile(
        "./data/alumnos.json",
        JSON.stringify(alumnos, null, 2)
      );
      res.json({ msg: "Alumno eliminado correctamente" });
    } else {
      res.status(404).json({ msg: "Alumno no encontrado" });
    }
  } catch (err) {
    res.status(500).json({ msg: "No se pudo eliminar el alumno" });
  }
});

module.exports = router;
