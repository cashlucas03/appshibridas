const alumnosRouter = require('./alumnosRouter');

function routerAPI( app ){
    app.use('/alumnos', alumnosRouter );
}

module.exports = routerAPI;