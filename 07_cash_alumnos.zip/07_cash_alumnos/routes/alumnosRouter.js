const express = require('express');
const router = express.Router();
const alumnosController = require('../controllers/alumnosControllers');

router.get('/', alumnosController.getWelcomePage);
router.get('/alumnos', alumnosController.getAlumnosList);
router.get('/alumnos/:legajo', alumnosController.getAlumno);
router.post('/alumnos', alumnosController.addAlumno);
router.put('/alumnos/:legajo', alumnosController.updateAlumno);
router.delete('/alumnos/:legajo', alumnosController.deleteAlumno);

module.exports = router;