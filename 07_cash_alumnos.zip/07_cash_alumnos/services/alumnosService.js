const fs = require('fs');
const path = require('path');

const alumnosFilePath = path.join(__dirname, '../data/alumnos.json');

const readAlumnosFile = () => {
  try {
    const data = fs.readFileSync(alumnosFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
};

const writeAlumnosFile = (data) => {
  fs.writeFileSync(alumnosFilePath, JSON.stringify(data, null, 2), 'utf-8');
};

exports.getAlumnos = () => {
  return readAlumnosFile();
};

exports.getAlumnoByLegajo = (legajo) => {
  const alumnos = readAlumnosFile();
  return alumnos.find((alumno) => alumno.legajo === legajo);
};

exports.addAlumno = (alumnoData) => {
  const alumnos = readAlumnosFile();
  const newAlumno = { ...alumnoData };
  alumnos.push(newAlumno);
  writeAlumnosFile(alumnos);
  return newAlumno;
};

exports.updateAlumno = (legajo, updatedAlumnoData) => {
  let alumnos = readAlumnosFile();
  const index = alumnos.findIndex((alumno) => alumno.legajo === legajo);
  if (index !== -1) {
    alumnos[index] = { ...alumnos[index], ...updatedAlumnoData };
    writeAlumnosFile(alumnos);
    return alumnos[index];
  }
  return null;
};

exports.deleteAlumno = (legajo) => {
  let alumnos = readAlumnosFile();
  const index = alumnos.findIndex((alumno) => alumno.legajo === legajo);
  if (index !== -1) {
    const deletedAlumno = alumnos.splice(index, 1)[0];
    writeAlumnosFile(alumnos);
    return deletedAlumno;
  }
  return null;
};
