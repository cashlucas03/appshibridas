const express = require('express');
const dataBase = require('./dataBase');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const dotenv = require('dotenv');
dotenv.config();

/*
const jwt = require('jsonwebtoken');
const clave = process.env.JWT_SECRET;
*/

app.use(bodyParser.json());

const routes = require('./routes');

app.use('/api', routes);



/*
function validarToken (req, res, next){
    const token = req.headers.authorization;
    
    if(!token){
        return res.status(401).json({msg: "No se pudo pasar el Token"})
    }

    token = token.split(' ')[1];

    jwt.verify(token, clave, (error, decoded) =>{
        if(error){
            return res.status(403).json({
                msg: "Token incorrecto"
            })
        }

        next();
    })

 
}

module.exports = {
    validarToken,
}

*/

dataBase.on( 'error', () => {
    console.error('Error de conexion con MongoDB')
});

dataBase.once( 'open', ()=> {
    console.log('Conexión con MongoDB');
})

app.get('/', (req, res) => {
    res.send('<h1>Primer Parcial Apps Hibridas</h1> <p>Lucas Cash</p>');
})

app.listen( port, () => {
    console.log('Servidor en el puerto ', port);
})