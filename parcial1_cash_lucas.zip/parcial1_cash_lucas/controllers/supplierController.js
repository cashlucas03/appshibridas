const Proveedor = require('../models/supplierModel');

const supplierController = {
  listarProveedores: async (req, res) => {
    try {
      const proveedores = await Proveedor.find();
      res.json(proveedores);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener los proveedores' });
    }
  },

  obtenerProveedorPorId: async (req, res) => {
    const { id } = req.params;
    try {
      const proveedor = await Proveedor.findById(id);
      if (!proveedor) {
        return res.status(404).json({ error: 'Proveedor no encontrado' });
      }
      res.json(proveedor);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener el proveedor' });
    }
  },

  crearProveedor: async (req, res) => {
    const { nombre, direccion, telefono } = req.body;
    try {
      const nuevoProveedor = new Proveedor({ nombre, direccion, telefono });
      const proveedorGuardado = await nuevoProveedor.save();
      res.status(201).json({
        msg: 'Proveedor almacenado',
        data: proveedorGuardado
    })
    } catch (error) {
      res.status(500).json({ error: 'Error al crear el proveedor' });
    }
  },

  actualizarProveedor: async (req, res) => {
    const { id } = req.params;
    const { nombre, direccion, telefono } = req.body;
    try {
      const proveedor = await Proveedor.findByIdAndUpdate(id, { nombre, direccion, telefono }, { new: true });
      if (!proveedor) {
        return res.status(404).json({ error: 'Proveedor no encontrado' });
      }
      res.json(proveedor);
    } catch (error) {
      res.status(500).json({ error: 'Error al actualizar el proveedor' });
    }
  },

  eliminarProveedor: async (req, res) => {
    const { id } = req.params;
    try {
      const proveedor = await Proveedor.findByIdAndRemove(id);
      if (!proveedor) {
        return res.status(404).json({ error: 'Proveedor no encontrado' });
      }
      res.json({ message: 'Proveedor eliminado correctamente' });
    } catch (error) {
      res.status(500).json({ error: 'Error al eliminar el proveedor' });
    }
  },
};

module.exports = supplierController;
