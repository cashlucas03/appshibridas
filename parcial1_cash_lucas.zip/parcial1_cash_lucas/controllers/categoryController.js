const Categoria = require('../models/categoryModel');

const categoryController = {
  listarCategorias: async (req, res) => {
    try {
      const categorias = await Categoria.find();
      res.json(categorias);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener las categorías' });
    }
  },

  obtenerCategoriaPorId: async (req, res) => {
    const { id } = req.params;
    try {
      const categoria = await Categoria.findById(id);
      if (!categoria) {
        return res.status(404).json({ error: 'Categoría no encontrada' });
      }
      res.json(categoria);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener la categoría' });
    }
  },

  crearCategoria: async (req, res) => {
    const { nombre, descripcion } = req.body;
    try {
      const nuevaCategoria = new Categoria({ nombre, descripcion });
      const categoriaGuardada = await nuevaCategoria.save();
      res.status(201).json({
        msg: 'Categoria creada',
        data: categoriaGuardada
    })
    } catch (error) {
      res.status(500).json({ error: 'Error al crear la categoría' });
    }
  },

  actualizarCategoria: async (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion } = req.body;
    try {
      const categoria = await Categoria.findByIdAndUpdate(id, { nombre, descripcion }, { new: true });
      if (!categoria) {
        return res.status(404).json({ error: 'Categoría no encontrada' });
      }
      res.json(categoria);
    } catch (error) {
      res.status(500).json({ error: 'Error al actualizar la categoría' });
    }
  },

  eliminarCategoria: async (req, res) => {
    const { id } = req.params;
    try {
      const categoria = await Categoria.findByIdAndRemove(id);
      if (!categoria) {
        return res.status(404).json({ error: 'Categoría no encontrada' });
      }
      res.json({ message: 'Categoría eliminada correctamente' });
    } catch (error) {
      res.status(500).json({ error: 'Error al eliminar la categoría' });
    }
  },
};

module.exports = categoryController;
