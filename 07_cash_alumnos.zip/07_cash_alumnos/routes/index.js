const alumnosRouter = require('./alumnosRouter');

function routerAPI (app){
    app.use('/', alumnosRouter);
}

module.exports = routerAPI;