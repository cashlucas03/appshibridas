const express = require("express");
const routerAPI = require("./routes");

const app = express();
const port = 2023;

app.use(express.json());

app.get("/", (req, res) => {
  res.send(`<h1> Bienvenidos </h1>
                <a href="alumnos"> Listado de Alumnos</a>`);
});

routerAPI(app);

app.listen(port, () => {
  console.log(`Escuchando servidor en el puerto ${port}`);
});
