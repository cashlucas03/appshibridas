const fs = require('fs');
const path = require('path');
const alumnosService = require('../services/alumnosService');


exports.getWelcomePage = (req, res) => {
  res.send('<h1>Bienvenidos</h1>' + '<a href="/alumnos">Listado de Alumnos</a>');
};

exports.getAlumnosList = (req, res) => {
  const alumnos = alumnosService.getAlumnos();
  let alumnosListHTML = '<ul>';
  
  alumnos.forEach((alumno) => {
    alumnosListHTML += `
      <li>
      ${alumno.nombre}
        <a href="/alumnos/${alumno.legajo}">
        Ver Detalle
        </a>
      </li>
    `;
  });

  alumnosListHTML += '</ul>';
  res.send('<h1>Listado de Alumnos</h1>' + alumnosListHTML)
};

exports.getAlumno = (req, res) => {
  const legajo = Number(req.params.legajo);
  const alumno = alumnosService.getAlumnoByLegajo(legajo);
  if (alumno) {
    res.json(alumno);
  } else {
    res.status(404).send('Alumno no encontrado');
  }
};

exports.addAlumno = (req, res) => {
  const alumnoData = req.body;
  const newAlumno = alumnosService.addAlumno(alumnoData);
  res.json(newAlumno);
};

exports.updateAlumno = (req, res) => {
  const legajo = req.params.legajo;
  const updatedAlumnoData = req.body;
  const updatedAlumno = alumnosService.updateAlumno(legajo, updatedAlumnoData);
  if (updatedAlumno) {
    res.json(updatedAlumno);
  } else {
    res.status(404).send('Alumno no encontrado');
  }
};

exports.deleteAlumno = (req, res) => {
  const legajo = req.params.legajo;
  const deletedAlumno = alumnosService.deleteAlumno(legajo);
  if (deletedAlumno) {
    res.json(deletedAlumno);
  } else {
    res.status(404).send('Alumno no encontrado');
  }
};
