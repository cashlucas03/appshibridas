const Cliente = require('../models/clientModel');

const bcrypt = require('bcrypt');
const salt = 10;

const jwt = require('jsonwebtoken');

const clave = process.env.JWT_SECRET;


const clienteController = {
  listarClientes: async (req, res) => {
    try {
      const clientes = await Cliente.find();
      res.json(clientes);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener los clientes' });
    }
  },

  obtenerClientePorId: async (req, res) => {
    const { id } = req.params;
    try {
      const cliente = await Cliente.findById(id);
      if (!cliente) {
        return res.status(404).json({ error: 'Cliente no encontrado' });
      }
      res.json(cliente);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener el cliente' });
    }
  },

  crearCliente: async (req, res) => {
    const { nombre, correo, direccion, password } = req.body;

    try {
      const passHash = await bcrypt.hash(password, salt);
      const nuevoCliente = new Cliente({ nombre, correo, direccion, password:passHash });
      if (!nombre || !correo || !password || !direccion){
        res.status(400).json({ msg: 'Faltan campos obligatorios' });
      }
      const clienteGuardado = await nuevoCliente.save();
      res.status(201).json({
        msg: 'Cliente guardado',
        data: clienteGuardado
    })
    } catch (error) {
      res.status(500).json({ error: 'Error al crear el cliente' });
    }
  },

  actualizarCliente: async (req, res) => {
    const { id } = req.params;
    const { nombre, correo, direccion, password } = req.body;
    try {
      const cliente = await Cliente.findByIdAndUpdate(id, { nombre, correo, direccion, password }, { new: true });
      if (!nombre || !correo || !password || !direccion){
        res.status(400).json({ msg: 'Faltan campos obligatorios' });
      }
      if (!cliente) {
        return res.status(404).json({ error: 'Cliente no encontrado' });
      }
      res.json(cliente);
    } catch (error) {
      res.status(500).json({ error: 'Error al actualizar el cliente' });
    }
  },

  eliminarCliente: async (req, res) => {
    const { id } = req.params;
    try {
      const cliente = await Cliente.findByIdAndRemove(id);
      if (!cliente) {
        return res.status(404).json({ error: 'Cliente no encontrado' });
      }
      res.json({ message: 'Cliente eliminado correctamente' });
    } catch (error) {
      res.status(500).json({ error: 'Error al eliminar el cliente' });
    }
  },

  autenticarCliente: async (req, res) => {
    const {correo, password} = req.body;
    const user = await Cliente.findOne({correo});
    if(!user){
      res.status(401).json({'msg': 'Usuario no encontrado'})
    }

    const passValida = await bcrypt.compare(password, user.password);
    

    if(!passValida){
      res.status(401).json({'msg': 'Usuario no encontrado'})
    }

    const token = jwt.sign({user: correo}, clave, {expiresIn:'1h'})

    res.status(201).json({'msg': 'Autenticacion correcta', token})
  

  }
};

module.exports = clienteController;
