const express = require('express');
const routerAPI = require('./routes/index');

const app = express();
const port = 2023;

app.use(express.json());

routerAPI(app)

app.listen(port, () => {
  console.log(`Escuchando en el puerto ${port}`);
});