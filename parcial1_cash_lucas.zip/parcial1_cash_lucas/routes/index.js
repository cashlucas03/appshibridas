const express = require('express');
const router = express.Router();

// const appFuncion = require('../app');

const productoController = require('../controllers/productController');
const clienteController = require('../controllers/clientController');
const pedidoController = require('../controllers/orderController');
const proveedorController = require('../controllers/supplierController');
const categoriaController = require('../controllers/categoryController');


router.get('/productos', productoController.listarProductos);
router.get('/productos/:id', productoController.obtenerProductoPorId);
router.post('/productos', productoController.crearProducto);
router.put('/productos/:id', productoController.actualizarProducto);
router.delete('/productos/:id', productoController.eliminarProducto);

router.get('/clientes', clienteController.listarClientes);
router.get('/clientes/:id', clienteController.obtenerClientePorId);
router.post('/clientes', clienteController.crearCliente);
router.post('/clientes/autenticacion', clienteController.autenticarCliente);
router.put('/clientes/:id', clienteController.actualizarCliente);
router.delete('/clientes/:id', clienteController.eliminarCliente);

router.get('/pedidos', pedidoController.listarPedidos);
router.get('/pedidos/:id', pedidoController.obtenerPedidoPorId);
router.post('/pedidos', pedidoController.crearPedido);
// router.post('/pedidos', appFuncion.validarToken , pedidoController.crearPedido);
router.put('/pedidos/:id', pedidoController.actualizarPedido);
router.delete('/pedidos/:id', pedidoController.eliminarPedido);

router.get('/proveedores', proveedorController.listarProveedores);
router.get('/proveedores/:id', proveedorController.obtenerProveedorPorId);
router.post('/proveedores', proveedorController.crearProveedor);
router.put('/proveedores/:id', proveedorController.actualizarProveedor);
router.delete('/proveedores/:id', proveedorController.eliminarProveedor);

router.get('/categorias', categoriaController.listarCategorias);
router.get('/categorias/:id', categoriaController.obtenerCategoriaPorId);
router.post('/categorias', categoriaController.crearCategoria);
router.put('/categorias/:id', categoriaController.actualizarCategoria);
router.delete('/categorias/:id', categoriaController.eliminarCategoria);

module.exports = router;
